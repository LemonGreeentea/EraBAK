﻿[패치]eratohoK1. 12.0 도시관리에 투자 여지 표시

  도시관리에 경제 상한까지의 성장 여지를 표시하는 컬럼을 추가
  총총 선택해 투자할 수 있는지 확인하는 것이 큰 일이었기 때문에

라이센스 같은 것

  ERB/SHOP/SHOP_SLG/SHOP_SLG33_도시관리. ERB
  아주 조금 고쳐 쓴 것 뿐인 것으로, 변경전의 파일과 동일시 해 주세요.

commit
https://github.com/YinXiaogui/eratohoK/commit/e63072e5cc857b977068191987e9a14c7d74119c
