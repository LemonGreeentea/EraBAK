﻿·한 것
포로의취급을 결정하는 장면에서,
모든 포로의취급을 일괄로 설정할 수 있도록(듯이).

·편집원
era 연희[戀姬] 20140319

·편집 부위
파일 EVENT_PRISONER.ERB 에 대해
  함수 @SETSTATE_PRISONER_SETALL 를 신규 작성
  함수 @SETSTATE_PRISONER 를 편집

·이 패치로 ERB에 추가된 부위의 취급에 대해
era 연희[戀姬]을 편집하는 (분)편은 자유롭게 취급해 주세요.
