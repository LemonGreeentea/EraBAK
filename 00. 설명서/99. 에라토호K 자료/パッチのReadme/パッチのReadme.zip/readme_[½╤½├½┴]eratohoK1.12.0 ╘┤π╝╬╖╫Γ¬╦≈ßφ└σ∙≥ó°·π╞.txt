﻿[パッチ]eratohoK1.12.0 都市管理に投資余地表示

　都市管理に経済上限までの成長余地を表示するカラムを追加
　ポチポチ選んで投資できるか確認するのが大変だったので

ライセンスっぽい物

　ERB/SHOP/SHOP_SLG/SHOP_SLG33_都市管理.ERB
　ほんの少し書き換えただけなので、変更前のファイルと同一視して下さい。

commit
https://github.com/YinXiaogui/eratohoK/commit/e63072e5cc857b977068191987e9a14c7d74119c
